﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Program
    {
        static void Main(string[] args)
        {

            //Construction classes generales
            ListePlanning lesPlannings = new ListePlanning();
            ListeDemande lesDemandes = new ListeDemande();
            ListeSalle lesSalles = new ListeSalle();
            ListeUtilisateur lesUtilisateurs = new ListeUtilisateur();


            Console.WriteLine("Bonjour,\n  veuillez saisir votre login et mot de passe... ");
            string nomAd = Console.ReadLine();
            string pw = Console.ReadLine();
            Administrateur a = new Administrateur(nomAd, pw);
            Console.WriteLine("Bonjour "+ nomAd);


            

            

            char verif = 'o';
            while(verif == 'o' || verif == 'O') {

                Console.WriteLine("Que voulez vous faire? ... ");
                Console.WriteLine("**********************************************************************");
                Console.WriteLine("0: ajouter une liste de salles ");
                Console.WriteLine("1: Consulter Salles");
                Console.WriteLine("2: Ajouter Utilisateur ");
                Console.WriteLine("3: Faire demande");
                Console.WriteLine("4: Consulter demande");
                int uc = Convert.ToInt32(Console.ReadLine());

                switch (uc)
                {

                    case 0:
                        Salle salle1 = new Salle(1, "workshop", 100, 'O', 'N', 15, 'O', 15, "Bon");
                        Salle salle2 = new Salle(2, "laboratoire", 142, 'N', 'O', 15, 'o', 15, "Mauvais");
                        Salle salle3 = new Salle(3, "repos", 237, 'o', 'o', 22, 'N', 22, "Bon");
                        Salle salle4 = new Salle(4, "réunion", 341, 'O', 'O', 21, 'o', 21, "Bon");
                        Salle salle5 = new Salle(5, "conférence", 135, 'N', 'N', 50, 'O', 50, "Bon");
                        Salle salle6 = new Salle(6, "vidéoconference", 221, 'N', 'N', 23, 'N', 15, "Mauvais");
                        lesSalles.ajouterSalle(salle1);
                        lesSalles.ajouterSalle(salle2);
                        lesSalles.ajouterSalle(salle3);
                        lesSalles.ajouterSalle(salle4);
                        lesSalles.ajouterSalle(salle5);
                        lesSalles.ajouterSalle(salle6);
                        break;
                    case 1:
                        Console.WriteLine("Liste des salles ajoutées: ");
                        Console.WriteLine(lesSalles.consulterSallesToString()); 
                        break;
                    case 2:
                        Console.WriteLine("Nom du nouveau utilisateur ...");
                        string u = Console.ReadLine();
                        Utilisateur newUser = new Utilisateur(u);
                        Console.WriteLine(lesUtilisateurs.ajouterUtilisateur(a, newUser));
                        break;
                    case 3:
                        Console.WriteLine("Pour quel utilisateur, voulez vous effectuer la demande ? ...");
                        string u1 = Console.ReadLine();
                        ProprietesDeLaSalle ps = new ProprietesDeLaSalle(1, "workshop", 100, 'O', 'N', 15, 'O', 15, "Bon");
                        ProprietesDeLaDisponibilite pd = new ProprietesDeLaDisponibilite(1, 1, 3, 1, 2, 1, 18, 11, 19);

                        ProprietesDeLaSalle ps2 = new ProprietesDeLaSalle(4, "réunion", 341, 'O', 'O', 21, 'o', 21, "Bon");
                        ProprietesDeLaDisponibilite pd2 = new ProprietesDeLaDisponibilite(1, 1, 3, 1, 2, 1, 18, 11, 19);
                        Demande d = new Demande(u1, ps, pd);
                        lesDemandes.ajouterDemande(d);
                        break;
                    case 4:
                        Console.WriteLine("Veuillez saisir le nom de l'utilisateur, pour lequel vous voulez consulter la demande...");
                        string nomUserDemande = Console.ReadLine();
                        Console.WriteLine(lesDemandes.getDemandesDUnUtilisateurToString(nomUserDemande));
                        break;
                }

                Console.WriteLine("Voulez vous continuer? ... (o/n)  ");
                verif = Console.ReadLine()[0];


            }
            


        }
    }
}
