﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Semaine
    {
        private List<Jour> lesJours = new List<Jour>();
        private int id = 0;

        public List<Jour> getLesJours()
        {
            return this.lesJours;

        }

        public int getId()
        {
            return this.id;
        }
    }
}
