﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class ListeDemande
    {
		List<Demande> lesDemandes;

		public ListeDemande()
		{
			this.lesDemandes = new List<Demande>();
		}

		public bool ajouterDemande(Demande d){

			this.lesDemandes.Add(d);

			return true;
		}
		
		public List<Demande> getDemandesDUnUtilisateur(string nomUtilisateur){

			List<Demande> demandesDUnUtilisateur = new List<Demande>();
			
			foreach(Demande d in lesDemandes){

				if(d.getNomDemandeur() == nomUtilisateur){
					demandesDUnUtilisateur.Add(d);

				}
			}


			return demandesDUnUtilisateur;
		}


		public string getDemandesDUnUtilisateurToString(string nomUtilisateur)
		{

			List<Demande> demandesDUnUtilisateur = new List<Demande>();

			foreach (Demande d in lesDemandes)
			{

				if (d.getNomDemandeur() == nomUtilisateur)
				{
					demandesDUnUtilisateur.Add(d);

				}
			}


			string demandesAConsulterToString = "";

			//Met en string les plannings de l'utilisateur
			foreach (Demande d in demandesDUnUtilisateur)
			{
				demandesAConsulterToString = demandesAConsulterToString
											 + "\nDemandeur :" + d.getNomDemandeur()
											 + "\nID de la salle: " + d.getPropsS().getId()
											 + "\nCapacité de la salle: " + d.getPropsS().getCap()
											 + "\nPrix de l'espace : " + d.getPropsS().getPrix()
											 + "\nNombre d'ordinateur : " + d.getPropsS().getNbOrdi()
											 + "\nPrésence de projecteur : " + d.getPropsS().getProj()
											 + "\nPrésence d'imprimante : " + d.getPropsS().getImpri()
											 + "\nPrésence de tableau : " + d.getPropsS().getTab()
											 + "\n****************************************************************"
											 + "\nHeure: " + d.getPropsD().getH1() + "h - " + d.getPropsD().getH2() + "h"
											 + "\nJour: " + d.getPropsD().getJ1() + " - " + d.getPropsD().getJ2()
											 + "\nSemaine: " + d.getPropsD().getS1() + " - " + d.getPropsD().getS2()
											 + "\nMois: " + d.getPropsD().getM1() + " - " + d.getPropsD().getM2();
			}


			return demandesAConsulterToString;
		}
		public List<Demande> getDemandes()
		{

			return this.lesDemandes;
		}


		public bool supprimerDemandesDUnUtilisateur(Administrateur admin, string nomUtilisateur){

			bool verif = false;
			foreach(Demande d in lesDemandes){
				if(d.getNomDemandeur() == nomUtilisateur){
					lesDemandes.Remove(d);

					verif = true;
				}
			}

			return verif;
		}
		
		public bool modifierDemandesDUnUtilisateur(string nomUtilisateur){
			bool verif = false;
			foreach(Demande d in lesDemandes){
				if(d.getNomDemandeur() == nomUtilisateur){
					Console.WriteLine("La salle a un tableau? (o/n) ");
					char tab = Console.ReadLine()[0];
					d.getPropsS().setTab(tab);

					Console.WriteLine("La salle a  une imprimante? (o/n) ");
					char imp = Console.ReadLine()[0];
					d.getPropsS().setImprimante(imp);

					Console.WriteLine("La salle a un projecteur? (o/n)");
					char proj = Console.ReadLine()[0];
					d.getPropsS().setProj(proj);

					Console.WriteLine("Saisir le nombre d'ordinateurs pour la salle");
					int nbOrdi = Convert.ToInt32( Console.ReadLine());
					d.getPropsS().setNbOrdi(nbOrdi);

					Console.WriteLine("Saisir la capacité pour la salle");
					int cap = Convert.ToInt32(Console.ReadLine());
					d.getPropsS().setCap(tab);

					Console.WriteLine("Saisir l'Id de la salle");
					int id = Convert.ToInt32(Console.ReadLine());
					d.getPropsS().setId(id);

					Console.WriteLine("Le type de la salle (workshop | laboratoire | reunion | repos | conférence | vidéoconference) ");
					string type = Console.ReadLine();
					d.getPropsS().setType(type);

					Console.WriteLine("L'état de la salle (bon | mauvais ) ");
					string etat = Console.ReadLine();
					d.getPropsS().setEtat(etat);

					verif = true;

				}
			}
			return verif;
		}





	}
}
