﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Demande
    {
        string nomDemandeur;
        ProprietesDeLaSalle propsS;
        ProprietesDeLaDisponibilite propsD;


        public Demande(string nom, ProprietesDeLaSalle ps, ProprietesDeLaDisponibilite pd)
        {
            this.nomDemandeur = nom;
            this.propsS = ps;
            this.propsD = pd;
        }
        public string getNomDemandeur()
        {
            return this.nomDemandeur;
        }

        public ProprietesDeLaDisponibilite getPropsD()
        {
            return this.propsD;
        }


        public ProprietesDeLaSalle getPropsS()
        {
            return this.propsS;
        }
    }
}
