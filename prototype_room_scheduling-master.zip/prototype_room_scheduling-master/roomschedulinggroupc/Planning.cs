﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Planning
    {
        string nomProprietaire;
        List<Salle> lesSalles;
        
       public Planning(string proprietaireDuPlanning, Salle s){
            this.nomProprietaire = proprietaireDuPlanning;
            this.lesSalles.Add(s);
        }

        public string getNomProprietaire()
        {
            return this.nomProprietaire;
        }
        public List<Salle> getSalles()
        {
            return this.lesSalles;
        }
    }
}
