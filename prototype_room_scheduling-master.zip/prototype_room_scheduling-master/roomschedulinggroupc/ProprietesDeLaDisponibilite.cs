﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class ProprietesDeLaDisponibilite
    {
        private int id;
        private int m1;
        private int m2;
        private int s1;
        private int s2;
        private int j1;
        private int j2;
        private int h1;
        private int h2;

        public ProprietesDeLaDisponibilite(int id, int m1, int m2, int s1, int s2, int j1, int j2, int h1, int h2)
        {
            this.id = id;
            this.m1 = m1;
            this.m2 = m2;
            this.h1 = h1;
            this.h2 = h2;
            this.s1 = s1;
            this.s2 = s2;
            this.j1 = j1;
            this.j2 = j2;

        }

        //Getters
        public int getId()
        {
            return this.id;
        }

        public int getH1()
        {
            return this.h1;
        }
        public int getH2()
        {
            return this.h1;
        }

        public int getM2()
        {
            return this.m2;
        }
        public int getM1()
        {
            return this.m1;
        }

        public int getS2()
        {
            return this.s2;
        }
        public int getS1()
        {
            return this.s1;
        }

        public int getJ2()
        {
            return this.j2;
        }

        public int getJ1()
        {
            return this.j1;
        }



        //Setters

        public void setId(int id)
        {
            this.id = id;
        }

        public void setH1(int h1)
        {
            this.h1 = h1;
        }
        public void setH2(int h2)
        {
            this.h2 = h2;
        }
        public void setM1(int m1)
        {
            this.m1 = m1;
        }
        public void setM2(int m2)
        {
            this.m2 = m2;
        }
        public void setS1(int s1)
        {
            this.s1 = s1;
        }
        public void setS2(int s2)
        {
            this.s2 = s2;
        }
        public void setJ1(int j1)
        {
            this.j1 = j1;
        }
        public void setJ2(int j2)
        {
            this.j2 = j2;
        }



    }
}
