﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Utilisateur
    {
        private string nomUtilisateur;
        private string login;
        private string mdp;

        public Utilisateur(string nom)
        {
            this.nomUtilisateur = nom;
            this.login = "root";
            this.mdp = "root";
        }

        public Utilisateur()
        {
            this.nomUtilisateur = "";
            this.login = "";
            this.mdp = "";
        }


        //Setters
        public void setLogin(string login)
        {
             this.login = login;
        }

        public void setMdp(string mdp)
        {
             this.mdp = mdp;
        }

        public void setNom(string nom)
        {
             this.nomUtilisateur = nom;
        }

        //Getters


        public string getLogin()
        {
            return this.login;
        }

        public string getMdp()
        {
            return this.mdp;
        }

        public string getNom()
        {
            return this.nomUtilisateur;
        }

    }
}
