﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Disponibilite
    {
        private List<Mois> lesMois = new List<Mois>();
        private string nomUtilisateur;


        public List<Mois> getLesMois()
        {
            return this.lesMois;

        }

        public void setNomUtilisateur(string nomUtilisateur)
        {
            this.nomUtilisateur = nomUtilisateur;
        }
    }
}
