﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class ProprietesDeLaSalle
    {
        private int id;
        private string type;
        private int prix_espace;
        private char projecteur;
        private char imprimante;
        private int nbOrdinateur;
        private char tableau;
        private int capacite;
        private string etat;


        public ProprietesDeLaSalle( int id, string type, int prix_espace, char projecteur, char imprimante, int nbOrdinateur, char tableau, int capacite, string etat)
        {
            this.id = id;
            this.prix_espace = prix_espace;
            this.imprimante = imprimante;
            this.projecteur = projecteur;
            this.nbOrdinateur = nbOrdinateur;
            this.capacite = capacite;
            this.type = type;
            this.tableau = tableau;
            this.etat = etat;


        }

        //Getters
        public string getEtat()
        {
            return this.etat;
        }
        public int getId()
        {
            return this.id;
        }

        public string getType()
        {
            return this.type;
        }

        public char getProj()
        {
            return this.projecteur;
        }

        public int getPrix()
        {
            return this.prix_espace;
        }

        public char getImpri()
        {
            return this.imprimante;
        }

        public int getNbOrdi()
        {
            return this.nbOrdinateur;
        }

        public char getTab()
        {
            return this.tableau;
        }

        public int getCap()
        {
            return this.capacite;
        }

        //Setters

        public void setId(int id)
        {
            this.id = id;
        }

        public void setType(string type)
        {
             this.type = type;
        }
        public void setImprimante(char impri)
        {
            this.imprimante = impri;
        }

        public void setProj(char proj)
        {
             this.projecteur = proj;
        }

        public void setPrix(int prix)
        {
             this.prix_espace = prix;
        }


        public void setNbOrdi(int nbOrdi)
        {
            this.nbOrdinateur = nbOrdi;
        }

        public void setTab(char tab)
        {
             this.tableau = tab;
        }

        public void setCap(int cap)
        {
             this.capacite = cap;
        }
        public void setEtat(string etat)
        {
            this.etat = etat;
        }
    }
}
