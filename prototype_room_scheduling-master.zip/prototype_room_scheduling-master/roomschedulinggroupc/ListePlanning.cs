﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
	class ListePlanning
	{
		private List<Planning> lesPlannings;

		public ListePlanning()
		{
			this.lesPlannings = new List<Planning>();
		}


		public bool ajouterPlanningsDUnUtilisateur(List<Planning> planningsDUnUtilisateurGenere)
		{
			foreach(Planning p in planningsDUnUtilisateurGenere)
			{
				this.lesPlannings.Add(p);
			}
			
			return true;


		}

		public string consulterPlanningsDUnUtilisateurToSting(string nomUtilisateur)
		{

			List<Planning> planningsAConsulter = new List<Planning>();

			//Recupere les plannings d'un utilisateur dans la liste des plannings
			foreach (Planning p in this.lesPlannings)
			{
				if (p.getNomProprietaire() == nomUtilisateur)
				{
					planningsAConsulter.Add(p);
				}
			}
			string planningsAConsulterToString = "";

			//Met en string les plannings de l'utilisateur
			foreach (Planning p in planningsAConsulter)
			{
				foreach(Salle s in p.getSalles())
				{
					planningsAConsulterToString = planningsAConsulterToString
											 + "\nID de la salle: " + s.getId()
											 + "\n******************************"
											 + "\nPropriétés de la salle: " + s.getTab()
											 + "\nType de la salle: " + s.getType()
											 + "\nPrésence d'imprimante dans la salle: " + s.getImpri()
											 + "\nPrésence d'un tableau dans la salle: " + s.getTab()
											 + "\nPrésence d'un projecteur dans la salle: " + s.getProj()
											 + "\nCapacité de la salle: " + s.getCap()
											 + "\nNombre d'ordinateur dans la salle: " + s.getNbOrdi()
											 + "\nPrix de la salle : " + s.getPrix()
											 + "\n******************************"
											 + "\nDisponibilités de la salle: ";
										


				}
				
			}

			
			return planningsAConsulterToString;

		}


		public bool supprimerPlanningsDUnUtilisateur(string admin, string nomUtilisateur)
		{
			bool verif = false;

			foreach (Planning p in lesPlannings)
			{
				if (p.getNomProprietaire() == nomUtilisateur)
				{
					lesPlannings.Remove(p);
					verif = true;
				}

			}

			return verif;

		}

		public List<Planning> getLesPlannings()
		{
			return this.lesPlannings;
		}

	}
}
