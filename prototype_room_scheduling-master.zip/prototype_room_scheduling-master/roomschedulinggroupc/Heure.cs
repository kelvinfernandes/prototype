﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Heure
    {
        private int id;
        private bool pris;

        public void setId(int id)
        {
            this.id = id;
        }

        public void setPris(bool pris)
        {
            this.pris = pris;
        }

        public int getId()
        {
            return this.id;
        }

        public bool getPris()
        {
            return this.pris;
        }

    }
}
