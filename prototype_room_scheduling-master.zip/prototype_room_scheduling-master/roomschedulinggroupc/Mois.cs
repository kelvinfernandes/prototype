﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Mois
    {
        private List<Semaine> lesSemaines;
        private int id ;

        public Mois()
        {
            this.id = 0;
            this.lesSemaines = new List<Semaine>();
        }

        public List<Semaine> getLesSemaines()
        {
            return this.lesSemaines;

        }

        public int getId()
        {
            return this.id;
        }
    }
}
