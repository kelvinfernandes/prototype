﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class ListeSalle
    {
        private List<Salle> lesSalles;


		public ListeSalle()
		{
			this.lesSalles = new List<Salle>();
		}

		public bool ajouterSalle(Salle s)
		{

			this.lesSalles.Add(s);

			return true;


		}

		public string consulterSallesToString()
		{

			List<Salle> sallesAConsulter = new List<Salle>();

			foreach (Salle s in lesSalles)
			{
				sallesAConsulter.Add(s);
			}

			string sallesAConsulterToString = "";

			//Met en string les plannings de l'utilisateur
			foreach (Salle s in sallesAConsulter)
			{
				sallesAConsulterToString = sallesAConsulterToString
											 + "\nID de la salle: " + s.getId()
											 + "\nCapacité de la salle: " + s.getCap()
											 + "\nPrix de l'espace : " + s.getPrix()
											 + "\nNombre d'ordinateur : " + s.getNbOrdi()
											 + "\nPrésence de projecteur : " + s.getProj()
											 + "\nPrésence d'imprimante : " + s.getImpri()
											 + "\nPrésence de tableau : " + s.getTab()
											 + "\n****************************************************************";


			}


			return sallesAConsulterToString;

		}
		public string consulterSallesParTypeToString(string typeSalle)
		{

			List<Salle> sallesAConsulter = new List<Salle>();

			foreach (Salle s in lesSalles)
			{
				if (s.getType() == typeSalle)
				{
					sallesAConsulter.Add(s);
				}
			}

			string sallesAConsulterToString = "";

			//Met en string les plannings de l'utilisateur
			foreach (Salle s in sallesAConsulter)
			{
				sallesAConsulterToString = sallesAConsulterToString
											 + "\nID de la salle: " + s.getId()
											 + "\nCapacité de la salle: " + s.getCap()
											 + "\nPrix de l'espace : " + s.getPrix()
											 + "\nNombre d'ordinateur : " + s.getNbOrdi()
											 + "\nPrésence de projecteur : " + s.getProj()
											 + "\nPrésence d'imprimante : " + s.getImpri()
											 + "\nPrésence de tableau : " + s.getTab()
											 + "\n****************************************************************";

			}


			return sallesAConsulterToString;

		}

		public List<Salle> getSalles()
		{
			return this.lesSalles;
		}



	}
}
