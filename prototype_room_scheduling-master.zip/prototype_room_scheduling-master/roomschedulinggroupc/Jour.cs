﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Jour
    {
        private List<Heure> lesHeures;
        private int id;

        public List<Heure> getLesHeures()
        {
            return this.lesHeures;

        }

        public int getId()
        {
            return this.id;
        }

    }
}
