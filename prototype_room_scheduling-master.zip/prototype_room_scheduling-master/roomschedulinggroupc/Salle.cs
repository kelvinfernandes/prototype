﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Salle
    {

        private int id;
        private string type;
        private int prix_espace;
        private char projecteur;
        private char imprimante;
        private int nbOrdinateur;
        private char tableau;
        private int capacite;
        private string etat;
        private Disponibilite laDisponibilite;


        public Salle(int id, string type, int prix, char p, char i, int nbO, char t, int cap, string etat)
        {
            this.id = id;
            this.prix_espace = prix;
            this.projecteur = p;
            this.imprimante = i;
            this.nbOrdinateur = nbO;
            this.tableau = t;
            this.capacite = cap;
            this.etat = etat;
        }

        


        //Getters
        public string getEtat()
        {
            return this.etat;
        }
        public int getId()
        {
            return this.id;
        }

        public int getPrix()
        {
            return this.prix_espace;
        }

        public char getImpri()
        {
            return this.imprimante;
        }
        public char getTab()
        {
            return this.tableau;
        }
        public int getNbOrdi()
        {
            return this.nbOrdinateur;
        }
        public char getProj()
        {
            return this.projecteur;
        }

        public int getCap()
        {
            return this.capacite;
        }
        public string getType()
        {
            return this.type;
        }

        public Disponibilite getDisponibilite()
        {
            return this.laDisponibilite;
        }


    }
}
