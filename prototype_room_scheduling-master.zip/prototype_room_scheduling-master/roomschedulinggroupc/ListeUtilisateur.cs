﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class ListeUtilisateur
    {
		private List<Utilisateur> lesUtilisateurs;

		public ListeUtilisateur()
		{
			this.lesUtilisateurs = new List<Utilisateur>();
		}
		
		public bool ajouterUtilisateur(Administrateur a, Utilisateur u){

			this.lesUtilisateurs.Add(u);

			return true;

		}

		public bool supprimerUnUtilisateur(Administrateur a, string nomUtilisateur) {

			bool verif = false;

			foreach (Utilisateur u in lesUtilisateurs) {
				if (u.getNom() == nomUtilisateur) {
					lesUtilisateurs.Remove(u);
					verif = true;
				}
			}
			return verif;
		}
		
		public Utilisateur consulterUnUtilisateur(string nomUtilisateur){

			Utilisateur l_utilisateur = new Utilisateur();

			foreach(Utilisateur u in lesUtilisateurs){
				if(u.getNom() == nomUtilisateur){
					l_utilisateur = u;
				}
			}

			return l_utilisateur;
		}


	}
}
