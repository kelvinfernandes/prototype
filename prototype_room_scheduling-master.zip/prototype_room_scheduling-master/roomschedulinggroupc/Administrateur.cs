﻿using System;
using System.Collections.Generic;
using System.Text;

namespace roomschedulinggroupc
{
    class Administrateur
    {
        private string login;
        private string mdp;

        public Administrateur(string login, string mdp)
        {
            this.login = login;
            this.mdp = mdp;
        }

        public List<Planning> genererPlanning(ListeSalle lesSalles, List<Demande> lesDemandesDUnUtilisateur, ListePlanning lesPlannings)
        {
           // bool verif = false;
            List<Planning> planningsDUnUtilisateur = new List<Planning>();

            foreach (Salle s in lesSalles.getSalles())
            {
                foreach (Demande d in lesDemandesDUnUtilisateur)
                {
                    if (s.getType() == d.getPropsS().getType())
                    {
                        if (s.getPrix() == d.getPropsS().getPrix())
                        {
                            if (s.getProj() == d.getPropsS().getProj())
                            {
                                if (s.getImpri() == d.getPropsS().getImpri())
                                {
                                    if (s.getNbOrdi() == d.getPropsS().getNbOrdi())
                                    {
                                        if (s.getTab() == d.getPropsS().getTab())
                                        {
                                            if (s.getCap() == d.getPropsS().getCap())
                                            {
                                                if (s.getEtat() == d.getPropsS().getEtat())
                                                {
                                                    s.getDisponibilite().setNomUtilisateur(d.getNomDemandeur());


                                                    
                                                    Planning p = new Planning(d.getNomDemandeur(), s);
                                                    planningsDUnUtilisateur.Add(p);

                                                    /*
                                                    foreach (Mois m in s.getDisponibilite().getLesMois())
                                                    {
                                                        if ((m.getId() >= d.getPropsD().getM1()) && (d.getPropsD().getM2() >= m.getId()))
                                                        {

                                                            foreach (Semaine sem in m.getLesSemaines())
                                                            {
                                                                if ((d.getPropsD().getS1() <= sem.getId()) && (d.getPropsD().getS2() <= sem.getId()))
                                                                {

                                                                    foreach (Jour j in sem.getLesJours())
                                                                    {
                                                                        if ((d.getPropsD().getJ1() <= j.getId()) && (d.getPropsD().getJ2() <= j.getId()))
                                                                        {
                                                                            foreach (Heure h in j.getLesHeures())
                                                                            {

                                                                                if ((d.getPropsD().getH1() <= h.getId()) && (d.getPropsD().getH2() <= h.getId()))
                                                                                {

                                                                                    //verifier si l'heure n'est pas pris.
                                                                                    if (h.getPris() == false)
                                                                                    {
                                                                                        h.setPris(true);
                                                                                        //Met le nom du dernier utilisateur qui a pris la disponibilité
                                                                                        s.getDisponibilite().setNomUtilisateur(d.getNomDemandeur());

                                                                                        verif = true;

                                                                                        Planning p = new Planning(d.getNomDemandeur(), s);
                                                                                        lesPlannings.ajouterPlanningsDUnUtilisateur(this, p);
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                        }

                                                    }*/




                                                }

                                            }


                                        }

                                    }

                                }


                            }



                        }

                    }



                }


                //Si aucune salle ne correspond aux criteres alors, retourne false
            }
            return planningsDUnUtilisateur;
        }
    }
}

